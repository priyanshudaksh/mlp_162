package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestClass {
	Employee emp = new Employee(1, "Daksh");
	List<Employee> employees = new ArrayList<Employee>();
	@RequestMapping("Emp")
	public List<Employee> fetchEmployee() {
		//employees.add(emp);
		return employees;
	}
	@RequestMapping("Emp/{eid}")
	public Employee fetchbyId(@PathVariable("eid") String eid) {
		int empid = Integer.parseInt(eid);
		if(empid==1) {
			return emp;
		}
		return null;
	}
	@RequestMapping(value = "/Emp/{id}/{name}", method = RequestMethod.PUT)
	public Employee saveEmp(@PathVariable("id") int id, @PathVariable("name") String name) {
		System.out.println(id + " " + name);
		Employee empl = new Employee(id, name);
		employees.add(empl);
		return empl;
	}
	@RequestMapping(value = "/Emp/delete/{id}", method = RequestMethod.DELETE)
	public String deleteEmployee(@PathVariable("id") String id) {
		int di = Integer.parseInt(id);
		System.out.println(di);
		for(Employee emp: employees) {
			if(emp.getEid()==(di)) {
				Employee empl = emp;
				employees.remove(empl);
				return "Done";
			}
		}
		return "Not Found";
			
	}

}
