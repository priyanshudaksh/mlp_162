package com.example.demo.jsonTest;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import com.example.demo.Employee;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonFromRest {
	
	public static void main(String[] args) {
		String inline = "";
		ObjectMapper mapper = new ObjectMapper();
		try
		{
			URL url = new URL("http://localhost:8080/Emp");
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			Scanner sc = new Scanner(url.openStream());
			while(sc.hasNext())
			{
				inline+=sc.nextLine();
			}
			System.out.println("\nJSON Response in String format"); 
			System.out.println(inline);
			sc.close();
			List<Employee> employee2 = Arrays.asList(mapper.readValue(inline, Employee[].class));
			for(Employee emp:employee2) {
				System.out.println(emp.getEid());
				System.out.println(emp.getEname());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
