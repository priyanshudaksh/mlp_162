package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerClass {
	@RequestMapping("/home")
	public String viewHome()
	{
		return "home.html";
	}
	@RequestMapping("/home/1")
	public String viewHome1()
	{
		return "home1.html";
	}
}
