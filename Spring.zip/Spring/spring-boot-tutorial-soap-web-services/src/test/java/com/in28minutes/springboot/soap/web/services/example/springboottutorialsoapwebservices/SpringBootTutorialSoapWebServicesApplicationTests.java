package com.in28minutes.springboot.soap.web.services.example.springboottutorialsoapwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTutorialSoapWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
